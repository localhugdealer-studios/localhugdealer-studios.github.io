# Enemy No. 1: Fact Sheet

Press page: https://www.localhugdealer.com/games/enemy-no-1/press/

| Field     | Value                                            |
| --------- | ------------------------------------------------ |
| Title     | Enemy No. 1                                      |
| Developer | LocalHugDealer Studios (solo developer)          |
| Based in  | Muizenberg, Cape Town, South Africa              |
| Release   | March 2027                                       |
| Platforms | Windows, , linux, macOS                          |
| Store     | Steam and itch.io. Free demo on itch.io          |
| Price     | $9.99                                            |
| Genre     | Twin-stick action roguelite                      |
| Players   | Single player                                    |
| Input     | Keyboard and mouse, gamepad                      |
| Engine    | Godot                                            |
| Languages | English                                          |
| Website   | https://www.localhugdealer.com/games/enemy-no-1/ |
| Trailer   | https://www.youtube.com/watch?v=8zA_CIim3F4      |

## One line

A twin-stick action roguelite where you are a number that grows, splits and merges, and the villain is the digit 1.

## Short description

A twin-stick action roguelite where you are a number and the villain is the digit 1. Shoot numbers, grow on what they drop, split for more guns and merge to survive. A 1 in any node stops it healing. Inspired by the escalating runs of Risk of Rain and the eat, grow and split mechanics of agar.io.

## Long description

Enemy No. 1 is a twin-stick action roguelite set on the number line. It takes its escalating runs from Risk of Rain and its eat, grow and split mechanics from agar.io. Your number is your health, your size and your damage. Shoot numbers, collect what they drop and watch your number climb. A bigger number hits harder and has more to lose.

Numero Uno, in his attempt to become | Absolute |, has caged Zero and corrupted every number with a 1 in it. Every pickup changes your number, and any part of you with a 1 in it stops healing. You are a cluster of nodes, and your primary weapon fires from every one of them. Split and you have more guns on smaller, more fragile bodies. Merge back up when you need to take a hit. It is also how you deal with a 1.

The swarm grows with every minute you spend and every stage you clear. Find the portal, defeat the guardians and get to Numero Uno, or keep playing in endless mode against the clock.

## Features

- **You are a number.** It is your health, your size and your damage. Make it bigger.
- **You have 1 problem.** Every pickup changes your number, and any part of you with a 1 in it stops healing. Split it: 100 becomes a 55 and a 45, and both of them heal and shoot.
- **Split for firepower. Merge to survive.** Your primary weapon fires from every node. Split and you have more guns on smaller, more fragile bodies. Merge back up when you need to take a hit.
- **Choose before your run.** One primary, one secondary, from a dozen+. The Common Denominator, Long Division, the Pi-stol, Null Set.
- **Knock the 1 out of an enemy's number and it switches sides.** The Square Rootcket does it to everything in its blast.
- **55+ stacking pickups** in four rarities. Chain Rule arcs lightning between enemies. Corollary turns kills into homing darts. Inverse Function brings you back from the dead, once.
- **10+ arena shapes** shuffled per run, and elites with their own tricks.
- **The clock is not on your side.** The swarm grows with every minute you spend and every stage you clear. Endless mode lets you keep going against the clock.
- **Between runs.** Imaginary numbers drop during runs, more often on the harder difficulties, and the Report Card (achievements) pays out more. Spend them on the (skill) Tree Diagram and new weapons. Puzzle sites pay out artifacts with bigger bonuses.
- **Find the portal and defeat the guardians.** Every guardian you beat brings you closer to defeating Numero Uno. About 20 minutes to reach him.
- **A shop called The Absolute Value.** Pay the Altar of Operations and its gate is guaranteed.
- **Neon vector art on a CRT**, and 10+ custom tracks to go with it.

## History

Enemy No. 1 began as Trust No 1, a prototype made for the Brackeys Game Jam 2026.2 at the end of August 2026 (https://localhugdealer.itch.io/trust-no-1). The joke at the centre of it, that a number with a 1 in it is corrupt, survived. Everything around it grew: splitting and merging, a pre-run loadout, stackable upgrades, permanent progression and a line of guardians leading to Numero Uno.

## Studio

LocalHugDealer Studios is a one-person game studio in Muizenberg, Cape Town. Enemy No. 1 is its first commercial game.

## Fonts

All four are free under the SIL Open Font License. The files and their licences are in `Fonts/`.

| Font           | Used for                                      | Link                                             |
| -------------- | --------------------------------------------- | ------------------------------------------------ |
| Rubik Mono One | The ENEMY NO. 1 title on the key art and logo | https://fonts.google.com/specimen/Rubik+Mono+One |
| Silkscreen     | The game's interface                          | https://fonts.google.com/specimen/Silkscreen     |
| Chakra Petch   | Subheadings on the website                    | https://fonts.google.com/specimen/Chakra+Petch   |
| IBM Plex Mono  | Body text on the website                      | https://fonts.google.com/specimen/IBM+Plex+Mono  |

## In this kit

- `Images/`: eight in-game screenshots, 1920x1080 PNG
- `Gifs/`: nine gameplay GIFs, 616x347
- `Key Art/`: the key art with the ENEMY NO. 1 title, as a 3840x2160 banner, a 2000x400 wide banner, a 748x896 Steam vertical capsule and a 600x900 Steam library capsule, all PNG
- `Videos/`: a six second animated title card, 1920x1080 MP4 without sound
- `Logos/`: the game logo (transparent PNG), the game icon at 500x500 and 1024x1024, and the studio logo
- `Fonts/`: the four fonts above, with their licences
